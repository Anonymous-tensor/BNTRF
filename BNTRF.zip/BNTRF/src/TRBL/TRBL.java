package TRBL;


import LFTcommom.InitTensor;
import LFTcommom.TensorTuple;
import java.util.Random;
import java.io.IOException;
import java.util.Arrays;


public class TRBL extends InitTensor{

    public double sumTime = 0;

    public int tr = 0;

    public int threshold = 0;

    public boolean flagRMSE = true, flagMAE = true;

    public String str = null;

    public double lambda = 0;
    public double lambda_b = 0;

    public double c1;
    public double c2;
    public double w;
    public double alpha;
    public int population = 0;

    public double[] maxX = {0.1, 0.1};
    public double[] minX = {0.01, 0.01};
    public double[] maxV = {0.2 * (maxX[0] - minX[0]), 0.2 * (maxX[1] - minX[1])};
    public double[] minV = {-0.2 *(maxX[0] - minX[0]), -0.2 * (maxX[1] - minX[1])};

    public double[][] pv;
    public double[][] px;

    public void InitPSO() {
        pv = new double[population][3];
        px = new double[population][3];
        Random random = new Random();
        for (int p = 0; p < population; p++) {
            for (int i = 0; i < 2; i++) {
                px[p][i] = minX[i] + random.nextDouble() * (maxX[i] - minX[i]);
                pv[p][i] = 0;
            }
        }
    }

    TRBL(String trainFile, String validFile, String testFile, String separator )
    {
        super(trainFile, validFile, testFile, separator);
    }

    public void train() throws IOException
    {
        long startTime = System.currentTimeMillis();

        initFactorMatrix();
        initAssistMatrix();

        InitPSO();

        double Init_square = 0, Init_absCount = 0;
        for (TensorTuple validTuple : validData) {
            // 获得元素的预测值
            validTuple.valueHat = this.getPrediction(validTuple.aID, validTuple.bID, validTuple.cID);
            Init_square += Math.pow(validTuple.value - validTuple.valueHat, 2);
            Init_absCount += Math.abs(validTuple.value - validTuple.valueHat);

        }
        double Init_fitness = alpha * Math.sqrt(Init_square / validCount) + (1 - alpha) * (Init_absCount / validCount);

        double[] pBest = new double[population];
        Arrays.fill(pBest, Integer.MIN_VALUE);
        double[][] pBest_value = new double[population][3];

        double gBest = Integer.MIN_VALUE;
        double[] gBest_value = new double[3];

        for(int round = 1; round <= trainRound; round++) {
            long startRoundTime = System.currentTimeMillis();

            double[] fitness = new double[population];

            for (int p = 0; p < population; p++) {
                {
                    initAssistMatrix();

                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r1 = 1; r1 <= rank; r1++) {
                            for (int r3 = 1; r3 <= rank; r3++) {
                                double temp = 0;
                                for (int r2 = 1; r2 <= rank; r2++) {
                                    temp += D[r1][trainTuple.bID][r2] * T[r2][trainTuple.cID][r3];
                                }
                                Sup[r3][trainTuple.aID][r1] += trainTuple.value * temp;
                                Sdown[r3][trainTuple.aID][r1] += trainTuple.valueHat * temp + px[p][0] * S[r3][trainTuple.aID][r1];
                            }
                        }
                    }

                    for(int i = 1; i <= this.maxAID; i++) {
                        for(int r1=1; r1 <= rank; r1++) {
                            for (int r3 = 1; r3 <= rank; r3++) {
                                Sup[r3][i][r1] = S[r3][i][r1] * Sup[r3][i][r1];
                                if(Sdown[r3][i][r1] != 0)
                                {
                                    S[r3][i][r1] = Sup[r3][i][r1] / Sdown[r3][i][r1];
                                }
                            }
                        }
                    }


                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r1 = 1; r1 <= rank; r1++) {
                            for (int r2 = 1; r2 <= rank; r2++) {
                                double temp = 0;
                                for (int r3 = 1; r3 <= rank; r3++) {
                                    temp += S[r3][trainTuple.aID][r1] * T[r2][trainTuple.cID][r3];
                                }
                                Dup[r1][trainTuple.bID][r2] += trainTuple.value * temp;
                                Ddown[r1][trainTuple.bID][r2] += trainTuple.valueHat * temp + px[p][0] * D[r1][trainTuple.bID][r2];
                            }
                        }
                    }

                    for(int i = 1; i <= this.maxBID; i++) {
                        for(int r1=1; r1 <= rank; r1++) {
                            for (int r3 = 1; r3 <= rank; r3++) {
                                Dup[r3][i][r1] = D[r3][i][r1] * Dup[r3][i][r1];
                                if(Ddown[r3][i][r1] != 0)
                                {
                                    D[r3][i][r1] = Dup[r3][i][r1] / Ddown[r3][i][r1];
                                }
                            }
                        }
                    }


                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r3 = 1; r3 <= rank; r3++) {
                            for (int r2 = 1; r2 <= rank; r2++) {
                                double temp = 0;
                                for (int r1 = 1; r1 <= rank; r1++) {
                                    temp += S[r3][trainTuple.aID][r1] * D[r1][trainTuple.bID][r2];
                                }
                                Tup[r2][trainTuple.cID][r3] += trainTuple.value * temp;
                                Tdown[r2][trainTuple.cID][r3] += trainTuple.valueHat * temp + px[p][0] * T[r2][trainTuple.cID][r3];
                            }
                        }
                    }

                    for(int i = 1; i <= this.maxCID; i++) {
                        for(int r1=1; r1 <= rank; r1++) {
                            for (int r3 = 1; r3 <= rank; r3++) {
                                Tup[r3][i][r1] = T[r3][i][r1] * Tup[r3][i][r1];
                                if(Tdown[r3][i][r1] != 0)
                                {
                                    T[r3][i][r1] = Tup[r3][i][r1] / Tdown[r3][i][r1];
                                }
                            }
                        }
                    }



                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r = 1; r <= rank; r++)
                        {
                            aup[trainTuple.aID][r] += trainTuple.value * b[trainTuple.bID][r] * c[trainTuple.cID][r];
                            adown[trainTuple.aID][r] += trainTuple.valueHat * b[trainTuple.bID][r] * c[trainTuple.cID][r] + px[p][1] * a[trainTuple.aID][r];
                        }
                    }

                    for(int i = 1; i <= this.maxAID; i++) {
                        for(int r=1; r <= rank; r++) {
                            aup[i][r] = a[i][r] * aup[i][r];
                            if(adown[i][r] != 0) {
                                a[i][r] = aup[i][r] / adown[i][r];
                            }
                        }
                    }


                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r = 1; r <= rank; r++)
                        {
                            bup[trainTuple.bID][r] += trainTuple.value * a[trainTuple.aID][r] * c[trainTuple.cID][r];
                            bdown[trainTuple.bID][r] += trainTuple.valueHat * a[trainTuple.aID][r] * c[trainTuple.cID][r] +px[p][1] * b[trainTuple.bID][r];
                        }

                    }

                    for(int j = 1; j <= this.maxBID; j++) {
                        for(int r=1; r <= rank; r++) {
                            bup[j][r] = b[j][r] * bup[j][r];
                            if(bdown[j][r] != 0) {
                                b[j][r] = bup[j][r] / bdown[j][r];
                            }
                        }
                    }


                    for(TensorTuple trainTuple: trainData)
                    {
                        trainTuple.valueHat = this.getPrediction(trainTuple.aID,trainTuple.bID, trainTuple.cID);

                        for(int r = 1; r <= rank; r++)
                        {
                            cup[trainTuple.cID][r] += trainTuple.value * a[trainTuple.aID][r] * b[trainTuple.bID][r];
                            cdown[trainTuple.cID][r] += trainTuple.valueHat * a[trainTuple.aID][r] * b[trainTuple.bID][r] +px[p][1] * c[trainTuple.cID][r];
                        }
                    }

                    for(int k = 1; k <= this.maxCID; k++) {
                        for(int r=1; r <= rank; r++) {
                            cup[k][r] = c[k][r] * cup[k][r];
                            if(cdown[k][r] != 0) {
                                c[k][r] = cup[k][r] / cdown[k][r];
                            }
                        }
                    }
                }

                double quare = 0, absCount = 0;
                for (TensorTuple validTuple : validData) {
                    validTuple.valueHat = this.getPrediction(validTuple.aID, validTuple.bID, validTuple.cID);
                    quare += Math.pow(validTuple.value - validTuple.valueHat, 2);
                    absCount += Math.abs(validTuple.value - validTuple.valueHat);

                }
                fitness[p] = alpha * Math.sqrt(Init_square / validCount) + (1 - alpha) * (Init_absCount / validCount);

            }

            double[] Fitness = new double[population];
            double Fdown = fitness[population - 1] - Init_fitness;
            for (int p = 0; p < population; p++)
            {
                if (p == 0)
                {
                    Fitness[p] = (fitness[p] - Init_fitness) / Fdown;
                }
                else Fitness[p] = (fitness[p] - fitness[p-1]) / Fdown;
            }


            for (int p = 0; p < population; p++) {
                if (Fitness[p] > pBest[p])
                {
                    pBest[p] = Fitness[p];
                    for (int h = 0; h < 2; h++)
                    {
                        pBest_value[p][h] =px[p][h];
                    }
                }
                if (Fitness[p] > gBest)
                {
                    gBest = Fitness[p];
                    for (int h = 0; h < 3; h++)
                    {
                        gBest_value[h] = px[p][h];
                    }
                }
            }

            for (int p = 0; p < population; p++) {
                Random random = new Random();
                double r1 = random.nextDouble();
                double r2 = random.nextDouble();
                for (int h = 0; h < 2; h++) {
                    pv[p][h] = w * pv[p][h] + c1 * r1 * (pBest_value[p][h] - px[p][h])
                            + c2 * r2 * (gBest_value[h] - px[p][h]);
                    if (pv[p][h] < minV[h]) {
                        pv[p][h] = minV[h];
                    }
                    if (pv[p][h] > maxV[h]) {
                        pv[p][h] = maxV[h];
                    }
                    px[p][h] += pv[p][h];
                    if (px[p][h] < minX[h]) {
                        px[p][h] = minX[h];
                    }
                    if (px[p][h] > maxX[h]) {
                        px[p][h] = maxX[h];
                    }
                }
            }

            double square = 0, absCount = 0;
            for (TensorTuple validTuple : validData) {
                // 获得元素的预测值
                validTuple.valueHat = this.getPrediction(validTuple.aID, validTuple.bID, validTuple.cID);
                square += Math.pow(validTuple.value - validTuple.valueHat, 2);
                absCount += Math.abs(validTuple.value - validTuple.valueHat);

            }
            everyRoundRMSE[round] = Math.sqrt(square / validCount);
            everyRoundMAE[round] = absCount / validCount;

            long endRoundTime = System.currentTimeMillis();
            sumTime += (endRoundTime-startRoundTime);

            double square2 = 0, absCount2 = 0;
            for (TensorTuple testTuple : testData) {
                testTuple.valueHat = this.getPrediction(testTuple.aID, testTuple.bID, testTuple.cID);
                square2 += Math.pow(testTuple.value - testTuple.valueHat, 2);
                absCount2 += Math.abs(testTuple.value - testTuple.valueHat);
            }

            everyRoundRMSE2[round] = Math.sqrt(square2 / testCount);
            everyRoundMAE2[round] = absCount2 / testCount;

            System.out.println((everyRoundRMSE2[round] + " " + everyRoundMAE2[round]));

            if (everyRoundRMSE[round-1] - everyRoundRMSE[round] > errorgap)
            {
                if(minRMSE > everyRoundRMSE[round])
                {
                    minRMSE = everyRoundRMSE[round];
                    minRMSERound = round;
                }

                flagRMSE = false;
                tr = 0;
            }

            if (everyRoundMAE[round-1] - everyRoundMAE[round] > errorgap)
            {
                if(minMAE > everyRoundMAE[round])
                {
                    minMAE = everyRoundMAE[round];
                    minMAERound = round;
                }

                flagMAE = false;
                tr = 0;
            }

            if(flagRMSE && flagMAE)
            {
                tr++;
                if(tr == threshold)
                    break;
            }

            flagRMSE = true;
            flagMAE = true;

        }

        long endTime = System.currentTimeMillis();

        System.out.println("time："+(endTime-startTime)/1000.00+"s\n");
        System.out.println("testing minRMSE:"+everyRoundRMSE2[minRMSERound]+"  minRSMERound"+minRMSERound);
        System.out.println("testing minMAE:"+everyRoundMAE2[minMAERound]+"  minMAERound"+minMAERound);

    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        TRBL bnlft = new TRBL("tr70%.txt",
                "va10%.txt",
                "te20%.txt","::");

        bnlft.initscale = 0.25;
        bnlft.initscale2 = 0.1;
        bnlft.threshold = 2;
        bnlft.rank = 5;
        bnlft.trainRound = 1000;
        bnlft.errorgap = 1E-5;
        bnlft.population = 5;
        bnlft.c1 = 2;
        bnlft.c2 = 2;
        bnlft.w = 0.724;
        bnlft.alpha = 0.5;

        try {
            bnlft.initData(bnlft.trainFile, bnlft.trainData, 1);
            bnlft.initData(bnlft.validFile, bnlft.validData, 2);
            bnlft.initData(bnlft.testFile, bnlft.testData, 3);
            bnlft.train();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

