package LFTcommom;

public class TensorTuple {
	
	public int aID = 0;
	public int bID = 0;
	public int cID = 0;
	
	public double value = 0;    
	public double valueHat = 0;    
	
	public double RMSEvalueHat = 0;
	
	public double MAEvalueHat = 0;

}
